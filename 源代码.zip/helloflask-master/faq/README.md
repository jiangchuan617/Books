# FAQ

这个文件夹内的`faq.md`文件包含[《Flask Web开发实战》](http://helloflask.com/book)的读者经常提出的问题与回答。

如果你想提一个问题，请创建Issue。