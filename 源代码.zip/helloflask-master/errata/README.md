# 勘误表
这个文件夹内的`errata.md`文件包含[《Flask Web开发实战》](http://helloflask.com/book)中的勘误信息。

首先，为书中包含的错误表示抱歉！如果你发现了书中的错误，欢迎提交PR更新勘误文件，具体注意事项请参考勘误目录下的`README`文件；或者，你也可以创建Issue指出相关错误，或是通过Email与我联系（withlihui@gmail.com），谢谢！
