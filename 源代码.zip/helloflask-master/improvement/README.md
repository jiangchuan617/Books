# 可改进实现
这个文件夹内的`improvement.md`文件包含[《Flask Web开发实战》](http://helloflask.com/book)中的可改进实现。

如果你发现了书中的可改进实现，欢迎提交PR更新可改进实现文件；你也可以创建Issue指出相关问题，或是通过Email与我联系（[withlihui@gmail.com](mailto:withlihui@gmail.com)），谢谢！